# v1.0.1

- Improved support for projects on network drives on windows. (VSCP-35)
- Added "Ext JS: Reindex Project for IntelliSense" command
- Reduced build size by 60%
- Now automatically indexes the Ext JS framework even when it's outside of the project. (VSCP-64)
- Fixed bug where errors from sencha app watch were not displayed. (VSCP-60)
- Fixed bug where an offline license could not be requested without having an open folder. (VSCP-62)

# v1.0.0

Initial GA release.